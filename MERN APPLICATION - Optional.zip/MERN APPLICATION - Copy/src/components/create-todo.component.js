import React, { Component } from "react";
import axios from "axios";

export default class CreateTodo extends Component {
  // constructor(props) {
  //   super(props);\
  constructor(props){
    super(props);


  }

    // this.
    onChangeActivity = this.onChangeActivity.bind(this);
    // this.
    onSubmit = this.onSubmit.bind(this);

    // this.
    state = {
      activity: "",
    };
  // }

  onChangeActivity(e) {
  
      console.log(this)
    this.setState({
      activity: e.target.value,
    });
  }

  onSubmit(e) {
    e.preventDefault();
     
    const activityvar = {
      activity: this.state.activity,
    };

    console.log(activityvar);

    axios.post("http://localhost:5000/todos/update/"+this.props.location.data.id, activityvar).then((res) => {
      window.location = "/";
    });
  }

  render() {
    return (
      <div>
        <h3>Make a change in Task</h3>
        <form onSubmit={this.onSubmit}>
          <div className="form-group">
            <label>Task: </label>
            <input
              type="text"
              required
              className="form-control"
              placeholder={this.props.location.data.aa}
              value={this.state.activity}
              onChange={this.onChangeActivity}
              
            />
          </div>

          <div className="form-group">
            <input
              type="submit"
              value="Create Activity Log"
              className="btn btn-primary"
            />
          </div>
        </form>
      </div>
    );
  }
}
